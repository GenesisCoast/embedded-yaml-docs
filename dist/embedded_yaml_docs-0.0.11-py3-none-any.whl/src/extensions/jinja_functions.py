class JinjaFunctions():
    """

    """


    pass