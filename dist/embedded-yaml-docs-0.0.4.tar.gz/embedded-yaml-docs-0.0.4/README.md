[![Build Status](https://travis-ci.org/GenesisCoast/embedded-yaml-docs.svg?branch=master)](https://travis-ci.org/GenesisCoast/embedded-yaml-docs)

[![PyPI version](https://badge.fury.io/py/embedded-yaml-docs.svg)](https://badge.fury.io/py/embedded-yaml-docs)

# YAML-Docs

YAML docs is a library dedicated for generating docs for YAML files using doc-strings.
