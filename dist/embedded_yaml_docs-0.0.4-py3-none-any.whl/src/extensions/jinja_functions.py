class JinjaFunctions():
    """

    """
    pass